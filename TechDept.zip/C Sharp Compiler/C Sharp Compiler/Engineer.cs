﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Engineer
    {
        private string name, dob;
        private int id, basesalary;

        public Engineer (string _name, int _id, string _dob, int _basesalary)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
        }

        public string Name
        {
            get { return name; }
        }

        public int ID
        {
            get { return id; }
        }

        public string DOB
        {
            get { return dob; }
        }

        public int BaseSalary
        {
            get { return basesalary; }
        }

        public void Bonus(int bonus)
        {
            basesalary += bonus;
        }
    }
}
