﻿using System;
using System.Collections.Generic;

namespace C_Sharp_Compiler
{
    class CTO
    {
        private string name, dob;
        private int id, basesalary;
        private List<Tech_Lead> techleads;
        private List<Engineer> engineers;

        public CTO(string _name, int _id, string _dob, int _basesalary)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
        }

        public CTO(string _name, int _id, string _dob, int _basesalary, List<Tech_Lead> _techleads)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
            techleads = _techleads;
        }

        public CTO(string _name, int _id, string _dob, int _basesalary, List<Tech_Lead> _techleads, List<Engineer> _engineers)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
            techleads = _techleads;
            engineers = _engineers;
        }

        public List<Tech_Lead> TechLead
        {
            get { return techleads; }
        }

        public List<Engineer> Engineers
        {
            get { return engineers; }
        }
        public string Name
        {
            get { return name; }
        }

        public int ID
        {
            get { return id; }
        }

        public string DOB
        {
            get { return dob; }
        }

        public int BaseSalary
        {
            get { return basesalary; }
        }

    }
}
