﻿using System;
using System.Collections.Generic;

namespace C_Sharp_Compiler
{

    public class MainClass
    {
        public static void Main(string[] args)
        {
            List<Tech_Lead> techleads = new List<Tech_Lead>
            {
                new Tech_Lead("Isla", 123, "12/28/1942", 147264),
                new Tech_Lead("Zelda", 234, "12/28/1942", 191982),
                new Tech_Lead("Adelmo", 345, "12/28/1942", 178491)
            };

            List<Engineer> engineers = new List<Engineer>
            {
                new Engineer("Eliana", 456, "12/28/1942", 147264),
                new Engineer("Matteo", 567, "12/28/1942", 191982),
                new Engineer("Saiki", 678, "12/28/1942", 178491)
            };

            CTO cto = new CTO("Ponyo", 789, "02/09/1944", 200402, techleads, engineers);
        }
    }

}
