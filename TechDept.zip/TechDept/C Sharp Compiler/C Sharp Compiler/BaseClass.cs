﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class BaseClass
    {
        private string name, dob;
        private int id, basesalary;

        public string Name
        {
            get { return name; }
        }

        public int ID
        {
            get { return id; }
        }

        public string DOB
        {
            get { return dob; }
        }

        public int BaseSalary
        {
            get { return basesalary; }
        }
    }
}
