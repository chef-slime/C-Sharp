﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Engineer : BaseClass
    {
        private string name, dob;
        private int id, basesalary;

        public Engineer (string _name, int _id, string _dob, int _basesalary)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
        }

        public void Bonus(int bonus)
        {
            basesalary += bonus;
        }
    }
}
