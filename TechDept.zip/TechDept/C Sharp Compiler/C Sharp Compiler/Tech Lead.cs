﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Tech_Lead : BaseClass
    {
        private string name, dob;
        private int id, basesalary;
        private List<Engineer> engineers;

        public Tech_Lead(string _name, int _id, string _dob, int _basesalary)
        {
            name = _name;
            id = _id;
            dob = _dob;
            basesalary = _basesalary;
        }


    }
}
