﻿using System.Collections.Generic;

namespace C_Sharp_Compiler
{
    class Manager
    {
        private string name;
        List<Fish> fishes;
        List<Reptiles> reptiles;
        List<Mammals> mammals;
        List<Birds> birds;

        public Manager(string _name)
        {
            name = _name;
        }
        public void Eliminate(Fish target)
        {
            fishes.Remove(target);
        }

        public void Eliminate(Reptiles target)
        {
            reptiles.Remove(target);
        }

        public void Eliminate(Mammals target)
        {
            mammals.Remove(target);
        }

        public void Eliminate(Birds target)
        {
            birds.Remove(target);
        }


        public int TotalFish
        {
            get { return fishes.Count; }


        }
        public int TotalReptiles
        {
            get { return reptiles.Count; }
        }

        public int TotalMammals
        {
            get { return mammals.Count; }
        }
        public int TotalBirds
        {
            get { return birds.Count; }
        }

        public int TotalOverall
        {
            get { return fishes.Count + reptiles.Count + mammals.Count + birds.Count; }
        }

    }
}
