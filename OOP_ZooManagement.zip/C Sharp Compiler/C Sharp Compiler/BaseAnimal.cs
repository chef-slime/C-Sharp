﻿namespace C_Sharp_Compiler
{
    interface BaseAnimal
    {
        public string GetName
        {
            get;
        }
        public string GetColor
        {
            get;
        }

        public int GetAge
        {
            get;
        }

    }
}
