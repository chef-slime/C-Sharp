﻿namespace C_Sharp_Compiler
{
    class Mammals : BaseAnimal
    {
        private string name, color;
        private int age;

        public Mammals(string _name, string _color, int _age)
        {
            name = _name;
            color = _color;
            age = _age;
        }

        public string GetName
        {
            get { return name; }
        }

        public string GetColor
        {
            get { return color; }
        }

        public int GetAge
        {
            get { return age; }
        }


    }
}
