﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MyFirstWinforms
{
    public partial class myMainForm : Form
    {
        private List<Personal> personalsList;

        public myMainForm()
        {
            InitializeComponent();
            personalsList = new List<Personal>();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lstbox.DataSource = null;

            personalsList.Add(new Personal(txtFirstname.Text, txtLastname.Text));

            lstbox.DataSource = personalsList;
            lstbox.DisplayMember = "Lastname";
        }

        #region nothing
        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstbox.DataSource = null;
            Personal selected = (Personal)lstbox.SelectedItem;

            personalsList.Remove(selected);

            lstbox.DataSource = personalsList;
            lstbox.DisplayMember = "Fullname";
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
        }

        private void btn18_Click(object sender, EventArgs e)
        {
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
        }

        private void txtFirstname_TextChanged(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
