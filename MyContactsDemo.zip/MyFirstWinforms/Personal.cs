﻿namespace MyFirstWinforms
{
    public class Personal
    {
        private string firstname;
        private string lastname;
        private Car myCar;

        public Personal(string _firstname, string _lastname)
        {
            firstname = _firstname;
            lastname = _lastname;
        }

        public Personal(string _firstname, string _lastname, Car _myCar)
        {
            firstname = _firstname;
            lastname = _lastname;
            myCar = _myCar;
        }

        // Property
        public string Fullname
        {
            get
            {
                return $"{firstname} {lastname}";
            }
        }

        public string Lastname
        {
            get
            {
                return $"{lastname}";
            }
        }
    }
}
