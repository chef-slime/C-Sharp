﻿
namespace MyFirstWinforms
{
    public class Car
    {
        private string color;

        public Car(string _color)
        {
            color = _color;
        }

        public string GetColor()
        {
            return color;
        }
    }
}
