﻿using _09_05_2020;
using System.Collections.Generic;

class MainClass
{
    public static void Main(string[] args)
    {

        List<Teacher> teachers = new List<Teacher> {
            new Teacher("Smith", "Math", 8),
            new Teacher("Ellan", "Phycis", 7)
        };

        List<Student> students = new List<Student> {
            new Student("ID123", 80),
            new Student("ID789", 77)
        };

        System.Console.WriteLine("What is your school name? ");
        string name = System.Console.ReadLine();

        School mySchool = new School(name, teachers, students);

        System.Console.WriteLine("Teachers are teaching: ");
        foreach (var teacher in mySchool.Teachers)
        {
            System.Console.WriteLine($"I am teaching {teacher.Subject}");
        }

        Student maxScoreStudent = new Student();
        int max = int.MinValue;
        foreach (var student in mySchool.Students)
        {
            if (student.Score > max)
            {
                max = student.Score;
                maxScoreStudent = student;
            }
        }

        System.Console.WriteLine($"The highest score is {maxScoreStudent.Score}");
    }
}
