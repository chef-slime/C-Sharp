﻿namespace _09_05_2020
{
    public class Student
    {
        private string id;
        private int score;

        public Student()
        {

        }

        public Student(string _id, int _score)
        {
            id = _id;
            score = _score;
        }

        public int Score
        {
            get { return score; }
        }
    }
}
