﻿using System.Collections.Generic;

namespace _09_05_2020
{
    public class School
    {
        private string name;
        private List<Teacher> teachers;
        private List<Student> students;

        public School(string _name)
        {
            name = _name;
        }

        public School(string _name, List<Teacher> _teachers)
        {
            name = _name;
            teachers = _teachers;
        }

        public School(string _name, List<Teacher> _teachers, List<Student> _students)
        {
            name = _name;
            teachers = _teachers;
            students = _students;
        }

        public List<Teacher> Teachers
        {
            get { return teachers; }
        }

        public List<Student> Students
        {
            get { return students; }
        }

        public string Name
        {
            get { return name; }
        }
    }
}
