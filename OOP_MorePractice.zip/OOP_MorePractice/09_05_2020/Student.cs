﻿namespace _09_05_2020
{
    public class Student
    {
        private string id;
        private int score;
        private int grade;

        public Student(string _id, int _grade, int _score)
        {
            id = _id;
            grade = _grade;
            score = _score;
        }

        public string ID
        {
            get { return id; }
        }

        public int Score
        {
            get { return score; }
        }

        public int Grade
        {
            get { return grade; }
        }

        public void GradePromotion(int gradeincrease)
        {
            grade += gradeincrease;
        }
    }
}
