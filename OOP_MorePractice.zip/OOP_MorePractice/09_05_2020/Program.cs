﻿using _09_05_2020;
using System.Collections.Generic;

class MainClass
{
    public static void Main(string[] args)
    {

        List<Teacher> teachers = new List<Teacher> {
            new Teacher("Smith", "Math", 5),
            new Teacher("Ellan", "Physics", 6),
            new Teacher ("Hinata", "Japanese", 3)
        };

        List<Student> students = new List<Student> {
            new Student("ID123", 6, 90),
            new Student("ID789", 12, 80)
        };

        System.Console.WriteLine("What is your school name? ");
        string name = System.Console.ReadLine();

        School mySchool = new School(name, teachers, students);

        System.Console.WriteLine($"\nSubjects taught at {name}: ");
        foreach (var teacher in mySchool.Teachers)
        {
            System.Console.WriteLine($"{teacher.Subject}");
        }

        Teacher maxrankteacher = null;
        int maxteacher = int.MaxValue;
        int physicscounter = 0;
        foreach (var teacher in mySchool.Teachers)
        {
            if (teacher.Name == "Ellan")
            { 
                teacher.DecreaseRank(1);
            }

            if (teacher.Subject != "Math" || teacher.Subject != "math")
            {
                teacher.IncreaseRank(2);
            }
            if (teacher.Rank < maxteacher)
            {
                maxteacher = teacher.Rank;
                maxrankteacher = teacher;
            }
            if (teacher.Subject == "Physics" || teacher.Subject == "physics")
            {
                physicscounter += 1;
            }
        }


        Student maxScoreStudent = null;
        Student minScoreStudent = null;
        int minstudent = int.MaxValue;
        int maxstudent = int.MinValue;
        int grade12students = 0;

        foreach (var student in mySchool.Students)
        {
            if (student.Score > maxstudent)
            {
                maxstudent = student.Score;
                maxScoreStudent = student;
            }
            if (student.Score< minstudent)
            {
                minstudent = student.Score;
                minScoreStudent = student;
            }
            if (student.Score > 80)
            {
                student.GradePromotion(1);
            }
            if (student.Grade == 12)
                grade12students += 1;
        }

        System.Console.WriteLine($"\nTeacher with highest rank is {maxrankteacher.Name}");

        System.Console.WriteLine($"\nHighest teacher rank is {maxteacher}");

        if (physicscounter == 1)
            System.Console.WriteLine($"\nThere is {physicscounter} teacher teaching physics.");
        else
            System.Console.WriteLine($"\nThere are {physicscounter} teachers teaching physics.");

        System.Console.WriteLine($"\nStudent with lowest score is {minScoreStudent.ID}");

        System.Console.WriteLine($"\nThe highest student score is {maxstudent}");

        if (grade12students == 1)
            System.Console.WriteLine($"\nThere is {grade12students} student in grade 12.");
        else
            System.Console.WriteLine($"\nThere are {grade12students} students in grade 12.");
    }
}
