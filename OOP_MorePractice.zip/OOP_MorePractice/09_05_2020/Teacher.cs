﻿
namespace _09_05_2020
{
    public class Teacher
    {
        private string name;
        private int rank;
        private string subject;

        public Teacher(string _name, string _subject, int _rank)
        {
            name = _name;
            subject = _subject;
            rank = _rank;
        }

        public string Subject
        {
            get { return subject; }
        }

        public int Rank
        {
            get { return rank; }
        }

        public string Name
        {
            get { return name; }
        }

        public void IncreaseRank(int increase)
        {
            rank -= increase;
        }
        
        public void DecreaseRank (int decrease)
        {
            rank += decrease;
        }
    }
}
