﻿using System;
using System.Windows.Forms;

namespace MyFirstWinforms
{
    public partial class myMainForm : Form
    {
        public myMainForm()
        {
            InitializeComponent();
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            if (lblDisplay.Text.Equals("0", StringComparison.OrdinalIgnoreCase))
            {
                lblDisplay.Text = btn17.Text;
            }
            else
            {
                lblDisplay.Text += btn17.Text;
            }
        }

        private void btn18_Click(object sender, EventArgs e)
        {
            if (lblDisplay.Text.Equals("0", StringComparison.OrdinalIgnoreCase))
            {
                lblDisplay.Text = btn18.Text;
            }
            else
            {
                lblDisplay.Text += btn18.Text;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lblDisplay.Text = "0";
        }
    }
}
