﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace MyFirstWinforms
{
    public partial class myMainForm : Form
    {
        private List<Personal> personalsList;

        public myMainForm()
        {
            InitializeComponent();
            personalsList = new List<Personal>();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            lstboxDisplay.DataSource = null;

            personalsList.Add(new Personal(txtFirstname.Text, txtLastname.Text));

            lstboxDisplay.DataSource = personalsList;
            lstboxDisplay.DisplayMember = "Fullname";

        }

        #region nothing
        private void btnRemove_Click(object sender, EventArgs e)
        {
            lstboxDisplay.DataSource = null;
            Personal selected = (Personal)lstboxDisplay.SelectedItem;

            personalsList.Remove(selected);

            lstboxDisplay.DataSource = personalsList;
            lstboxDisplay.DisplayMember = "Fullname";
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
        }

        private void btn18_Click(object sender, EventArgs e)
        {
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
        }

        private void txtFirstname_TextChanged(object sender, EventArgs e)
        {
        }

        #endregion
    }
}
