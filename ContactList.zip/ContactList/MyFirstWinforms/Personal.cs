﻿using System;
using System.Collections.Generic;

namespace MyFirstWinforms
{
    public class Personal
    {
        private string firstname;
        private string lastname;
        private int phonenumber;

        public Personal(string _firstname, string _lastname)
        {
            firstname = _firstname;
            lastname = _lastname;
        }

        public Personal(string _firstname, string _lastname, int _phonenumber)
        {
            firstname = _firstname;
            lastname = _lastname;
            phonenumber = _phonenumber;
        }

        // Property
        public string Firstname
        {
            get
            {
                return $"{firstname}";
            }
        }
        public string Lastname
        {
            get
            {
                return $"{lastname}";
            }
        }
        public string Phonenumber
        {
            get
            {
                return $"{phonenumber}";
            }
        }

        public string Fullname
        {
            get
            {
                return $"{firstname} {lastname}\n";
            }
        } 
    }
}
