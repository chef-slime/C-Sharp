﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class VanGlassware : IGlassware
    {
		public string Glasswareparts
		{
			get
			{
				return "Glassware parts for a van";
			}
		}
	}
}
