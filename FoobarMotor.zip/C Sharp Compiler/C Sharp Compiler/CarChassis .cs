﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class CarChassis : IChassis
    {
		public string Chassisparts
		{
			get
			{
				return "Chassis parts for a car";
			}
		}
	}
}
