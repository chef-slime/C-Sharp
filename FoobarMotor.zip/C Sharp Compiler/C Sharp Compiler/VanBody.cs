﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class VanBody
    {
		public string Bodyparts
		{
			get
			{
				return "Body shell parts for a van";
			}
		}
	}
}
