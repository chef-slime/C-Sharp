﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    interface IChassis
    {
        string Chassisparts
        {
            get;
        }
    }
}
