﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class VanChassis : IChassis
    {
		public string Chassisparts
		{
			get
			{
				return "Chassis parts for a van";
			}
		}
	}
}
