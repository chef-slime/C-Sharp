﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class CarBody : IBody
    {
		public string Bodyparts
		{
			get
			{
				return "Body shell parts for a car";
			}
		}
	}
}
