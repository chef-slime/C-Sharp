﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    interface IGlassware
    {
        string Glasswareparts
        {
            get;
        }
    }
}
