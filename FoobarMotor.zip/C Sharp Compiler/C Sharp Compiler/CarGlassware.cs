﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class CarGlassware : IGlassware
    {
		public string Glasswareparts
		{
			get
			{
				return "Glassware parts for a car";
			}
		}
	}
}
