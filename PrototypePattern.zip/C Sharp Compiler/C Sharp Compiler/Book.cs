﻿using System;

namespace C_Sharp_Compiler
{
    public class Book
    {
        public string title, publisher;
        public DateTime releaseDate;
        public IdInfo idinfo;

        // A book consists of 4 parts
        public Book(string _title, string _creator, IdInfo _id, DateTime _releaseDate)
        {
            title = _title;
            publisher = _creator;
            releaseDate = _releaseDate;
            idinfo = _id;
        }

        public Book ShallowCopy()
        {
            // Keyword "this" refers to current object in a method
            //MemberwiseClone creates a shallow copy of an object
            return (Book)this.MemberwiseClone();
        }

        public Book DeepCopy()
        {
            // Assigning shallow copy of object to variable of type "Book"
            Book clone = (Book)this.MemberwiseClone();

            // Clone will be using the same ISBN provided in the constructor just with different reference value
            clone.idinfo = new IdInfo(idinfo.id);

            return clone;
        }
         
            
    }
}
