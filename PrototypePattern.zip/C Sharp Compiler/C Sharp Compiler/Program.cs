﻿using System;

namespace C_Sharp_Compiler
{
    class Program
    {
        public static void Main(string[] args)
        {
            // Creating a new book with the following information entered into the constructor
            // A new object of class IdInfo must be generated
            Book b1 = new Book("Classroom of the Elite", "Seven Seas Entertainment", new IdInfo(9781642751376), Convert.ToDateTime("2019-05-07"));

            // b2 is a clone of b1 with some modifications
            Book b2 = b1.ShallowCopy();

            // b3 is b1's identical twin (same external appearance but different DNA)
            Book b3 = b1.DeepCopy();

            Console.WriteLine("Original values of b1, b2, b3:");
            Console.WriteLine("\nb1 instance values: ");
            DisplayValues(b1);
            Console.WriteLine("\nb2 instance values:");
            DisplayValues(b2);
            Console.WriteLine("\nb3 instance values:");
            DisplayValues(b3);

            // Change b1's properties
            b1.title = "Hatchet";
            b1.publisher = "MacMillan";
            b1.idinfo.id = 9781416936473;
            b1.releaseDate = Convert.ToDateTime("1986-11-01");
            Console.WriteLine("\nValues of b1, b2 and b3 after changes to b1:");
            Console.WriteLine("\nb1 instance values: ");
            DisplayValues(b1);

            // ISBN for "Hatchet" is still the same because b1 and b2 have the same reference values for IdInfo instances
            Console.WriteLine("\nb2 instance values:");
            DisplayValues(b2);

            /* Deep copy of b1 keeps the original ISBN because although the values are the same,
            the memory address that stores b1's and b3's ids are different */
            Console.WriteLine("\nb3 instance values:");
            DisplayValues(b3);
        }

        public static void DisplayValues(Book book)
        {
            Console.WriteLine("Title: {0}, Publisher: {1}, Release Date: {2:MM/dd/yy}",
                book.title, book.publisher, book.releaseDate);
            Console.WriteLine($"ISBN: {book.idinfo.id}");
        }
    }
}