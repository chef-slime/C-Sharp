﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    public class IdInfo
    {
        public long id;
        public IdInfo(long _id)
        {
            id = _id;
        }
    }
}
