﻿namespace CSharpCompiler
{
    class Food
    {
        private Food() { }

        private static Food food;

        /* "readonly keyword is used to declare a member variable a constant, 
            but allows the value to be calculated at runtime. 
            This differs from a constant declared with the const modifier, 
            which must have its value set at compile time" */


        // object keyword identifies type of object at run time only and can store any variable type
        private static readonly object _lock = new object();

        public static Food GetFood(string order)
        {
            // Check if we need to create the object and only in that case we would acquire a lock
            if (food == null)
            {
                /* Lock will block other threads from executing the code contained in the lock block.
                Threads will have to wait until the thread inside the lock block has completed */
                lock (_lock)
                {
                    /* Example of double check locking to see if another thread 
                        may have created an object between the if condition and lock statement

                        "2nd null check makes sure that only the 1st thread to acquire the lock creates the instance
                        Other threads will find the instance to be populated and skip ahead" */

                    if (food == null)
                    {
                        food = new Food();
                        food.Value = order;
                    }
                }
            }
            return food;
        }

        public string Value { get; set; }

    }
}
