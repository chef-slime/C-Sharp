﻿using System.Threading;
using System;

namespace CSharpCompiler
{
    class Program
    {
        public static void Main(string[] args)
        {
            /* => is an annonymous delegate (reference type variable for a method)
            You're defining a method without giving it a name. Its parameters are to the left of the => and
            the method body is to the right of the => */
            Thread process1 = new Thread(() =>
            {
                TestSingleton("cookies");
            });
            process1.Start();

            Thread process2= new Thread(() =>
            {
                TestSingleton("pie");
            });
            process2.Start();
        }

        public static void TestSingleton(string order)
        {
            Food instance = Food.GetFood(order);
            Console.WriteLine(instance.Value);
        }
    }
}