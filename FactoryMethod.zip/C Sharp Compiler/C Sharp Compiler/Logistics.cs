﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    // Creation of abstract class to be instantiated through subclasses
    abstract class Logistics
    {
        // Creation of method contained within ITransport
        public abstract ITransport createTransport();

        public string planDelivery()
        {
            // vehicle is the class of products to be returned
            var vehicle = createTransport();

            // Depending on the object in variable "vehicle," Deliver method will return a certain product
            var result = vehicle.Deliver();

            return result;
        }

    }
}

