﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    // For subclasses to return different types of products, these products must have a common base class or interface
    interface ITransport
    {
        string Deliver();
    }
}
