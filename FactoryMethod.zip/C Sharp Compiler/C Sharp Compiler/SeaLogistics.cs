﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class SeaLogistics : Logistics
    {
        // Override createTransport method to return a specific product class
        public override ITransport createTransport()
        {
            return new Ship();
        }

        /* Note: planDelivery method is not included here because 
        the "derived class reuses the code in the base class without having to reimplement it" */          
    }
}
