﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class RoadLogistics : Logistics
    {
        public override ITransport createTransport()
        {
            return new Truck();
        }

    }
}
