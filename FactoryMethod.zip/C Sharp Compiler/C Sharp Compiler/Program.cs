﻿using System;
using System.Collections.Generic;

class Program
{
    public static void Main(string[] args)
    {

    }
}