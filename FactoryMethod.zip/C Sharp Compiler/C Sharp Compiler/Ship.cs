﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Ship: ITransport
    {
        public string Deliver()
        {
            return "Ship";
        }
    }
}
