﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    // Declares a set of methods to return abstract products of the same family
    public interface FoodFactory
    {
        IAbstractMilk CreateMilk();
        IAbstractCheese CreateCheese();

    }
}
