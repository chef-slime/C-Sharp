﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    public interface IAbstractMilk
    {
        string getName();
    }
}
