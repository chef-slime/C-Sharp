﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    // An implementation of one abstract product
    public class Whole_Milk : IAbstractMilk
    {
        public string getName()
        {
            return "LiveRight Whole Milk";
        }
    }
}
