﻿using System;

namespace C_Sharp_Compiler
{
    class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}