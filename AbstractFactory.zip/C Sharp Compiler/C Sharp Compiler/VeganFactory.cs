﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class VeganFactory : Food_Factory
    {
        public IAbstractMilk CreateMilk()
        {
            return new Vegan_Milk();
        }
        public IAbstractCheese CreateCheese()
        {
            return new Vegan_Cheese();
        }
    }
}
