﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    // Implement methods of Food Factory interface
    // Produces a set of distinct but related products which make up a product family
    class WholeMilk_Factory : Food_Factory
    {
        public IAbstractMilk CreateMilk()
        {
            return new Whole_Milk();
        }

        public IAbstractCheese CreateCheese()
        {
            return new WholeMilk_Cheese();
        }
    }
}
