﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Vegan_Cheese : IAbstractCheese
    {
        public string getName()
        {
            return "LiveRight Vegan Cheese";
        }
    }
}
