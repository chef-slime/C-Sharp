﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class Vegan_Milk : IAbstractMilk
    {
        public string getName()
        {
            return "LiveRight Vegan Milk";
        }
    }
}
