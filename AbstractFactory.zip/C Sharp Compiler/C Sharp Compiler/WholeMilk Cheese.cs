﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C_Sharp_Compiler
{
    class WholeMilk_Cheese : IAbstractCheese
    {
        public string getName()
        {
            return "LiveRight Whole Milk Cheese";
        }
    }
}
