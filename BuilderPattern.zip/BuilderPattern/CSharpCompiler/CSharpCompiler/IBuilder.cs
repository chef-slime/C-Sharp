﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpCompiler
{
    // Define common construction steps for building all available product representations
    public interface IBuilder
    {
        void buildBread();
        void addSpread();
        void addFilling();
        void addGarnish();
    }
}
