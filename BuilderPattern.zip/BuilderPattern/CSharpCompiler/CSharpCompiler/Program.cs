﻿using System;
using System.Collections.Generic;

namespace CSharpCompiler
{
    class Program
    {
        public static void Main(string[] args)
        {
            Director director = new Director();

            Sandwich_Builder sandwichbuilder = new Sandwich_Builder();

            // Director works with builder instance that client passes to it
            director.Sandwich_Builder = sandwichbuilder;

            Console.WriteLine("Basic product:");
            director.buildMinimalProduct();
            Console.WriteLine(sandwichbuilder.GetSandwich().listParts());

            Console.WriteLine("Full product:");
            director.buildFullProduct();
            Console.WriteLine(sandwichbuilder.GetSandwich().listParts());

            Console.WriteLine("Custom product:");
            sandwichbuilder.buildBread();
            sandwichbuilder.addFilling();
            Console.WriteLine(sandwichbuilder.GetSandwich().listParts());
        }
    }
}