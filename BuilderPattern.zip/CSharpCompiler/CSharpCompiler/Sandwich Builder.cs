﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpCompiler
{
    // Implements steps from iBuilder
    public class Sandwich_Builder: iBuilder
    {
        // Creates an instance of Sandwich
        private Sandwich sandwich = new Sandwich();

        public void buildBread()
        {
            this.sandwich.Add("Whole grain bread");
        }
        public void addSpread()
        {
            this.sandwich.Add("Hummus");
        }
        public void addFilling()
        {
            this.sandwich.Add("Tofu patty");
            this.sandwich.Add("Cashew mozzarrella");
            this.sandwich.Add("Avocado");
        }

        public void addGarnish()
        {
            this.sandwich.Add("Cabbage");
            this.sandwich.Add("Shredded carrots");
        }

        // Constructor where any new instances of Sandwich_Builder is blank
        public Sandwich_Builder()
        {
            this.Reset();
        }

        // Reset method disposes of previous result
        // Client creates new sandwich builder = New sandwich object
        public void Reset()
        {
            this.sandwich = new Sandwich();
        }

        // GetSandwich is a method that returns Sandwich object (the list of ingredients)
        public Sandwich GetSandwich()
        {
            Sandwich result = this.sandwich;

            this.Reset();

            return result;
        }
    }
}
