﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpCompiler
{
    public class Director
    {

        // This is an interface reference variable, which refers to any object that implements the interface
        // and only knows methods declared in the inferface
        private iBuilder sandwichbuilder;

        // Properties allow you to read or write to a private field (variable within a class)
        public iBuilder Sandwich_Builder
        {
            // "value" keyword references the value that client code is attempting to assign 
            set { sandwichbuilder = value; }
        }

        public void buildMinimalProduct()
        {
            this.sandwichbuilder.buildBread();
        }

        public void buildFullProduct()
        {
            this.sandwichbuilder.buildBread();
            this.sandwichbuilder.addSpread();
            this.sandwichbuilder.addFilling();
            this.sandwichbuilder.addGarnish();
        }

    }
}
