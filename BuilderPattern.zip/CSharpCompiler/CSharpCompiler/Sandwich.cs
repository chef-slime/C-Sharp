﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpCompiler
{
    // Defines parts needed to make sandwich
    public class Sandwich
    {
        private List<object> ingredients = new List<object>();

        public void Add(string ingredient)
        {
            this.ingredients.Add(ingredient);
        }

        public string listParts()
        {
            string str = string.Empty;

            for (int i = 0; i < this.ingredients.Count; i++)
                str += this.ingredients[i] + ", ";

            // Removes last ", "
            str = str.Remove(str.Length - 2);

            return "Product parts: " + str + "\n";
        }
    }
}
