﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSharpCompiler
{
    // Define common construction steps for building all available product representations
    public interface iBuilder
    {
        void buildBread();
        void addSpread();
        void addFilling();
        void addGarnish();
    }
}
